import { SiteConfig, SiteElement, SitePage } from '../types';

export function generateHTML(config: SiteConfig): string {
  const pages = config.pages;
  const isMultiPage = pages.length > 1;

  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${escapeHtml(config.title)}</title>
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body {
      font-family: ${config.globalStyles.fontFamily};
      background-color: ${config.globalStyles.backgroundColor};
      min-height: 100vh;
    }
    .page { display: none; min-height: 100vh; position: relative; }
    .page.active { display: block; }
    .page-content { position: relative; z-index: 1; max-width: 900px; margin: 0 auto; padding: 24px; }
    .video-bg { position: fixed; top: 0; left: 0; width: 100%; height: 100%; object-fit: cover; z-index: 0; }
    .nav-bar {
      background: rgba(255,255,255,0.95);
      backdrop-filter: blur(10px);
      border-bottom: 1px solid #e5e7eb;
      padding: 12px 24px;
      display: flex;
      gap: 8px;
      flex-wrap: wrap;
      align-items: center;
      position: sticky;
      top: 0;
      z-index: 100;
    }
    .nav-bar a, .nav-bar button {
      padding: 8px 20px;
      border-radius: 20px;
      font-size: 14px;
      font-weight: 500;
      cursor: pointer;
      border: none;
      text-decoration: none;
      background: #f3f4f6;
      color: #374151;
      transition: all 0.2s;
    }
    .nav-bar button.active { background: ${config.globalStyles.primaryColor}; color: white; }
    .nav-bar button:hover { background: #e5e7eb; }
    .nav-bar button.active:hover { opacity: 0.9; }
    .site-title { font-weight: 700; font-size: 16px; margin-right: 16px; color: #1f2937; }
    .element { margin-bottom: 16px; }
    .btn-link {
      display: inline-block;
      text-decoration: none;
      transition: opacity 0.2s;
    }
    .btn-link:hover { opacity: 0.85; }
    img { max-width: 100%; }
    video { max-width: 100%; }
    .footer {
      text-align: center;
      padding: 24px;
      font-size: 12px;
      color: #9ca3af;
      position: relative;
      z-index: 1;
    }
  </style>
</head>
<body>
${isMultiPage ? generateNav(config) : ''}
${pages.map((page, i) => generatePage(page, i === 0, config)).join('\n')}
<div class="footer">Created & Owned by Muhammad Taqi | Built with TaqiSite Builder</div>
${isMultiPage ? generateScript() : ''}
</body>
</html>`;
}

function escapeHtml(str: string): string {
  return str.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

function generateNav(config: SiteConfig): string {
  return `<div class="nav-bar">
  <span class="site-title">${escapeHtml(config.title)}</span>
  ${config.pages.map((p, i) => `<button onclick="showPage('${p.id}')" class="page-btn${i === 0 ? ' active' : ''}" data-page="${p.id}">${escapeHtml(p.name)}</button>`).join('\n  ')}
</div>`;
}

function generatePage(page: SitePage, isFirst: boolean, config: SiteConfig): string {
  const bg = page.background;
  let bgLayerHtml = '';
  let overlayHtml = '';
  let containerStyle = '';

  // Background filter
  const bgFilter = (bg.brightness !== undefined && bg.brightness !== 100) || (bg.blur !== undefined && bg.blur !== 0)
    ? `filter: brightness(${bg.brightness || 100}%) blur(${bg.blur || 0}px);`
    : '';

  if (bg.type === 'color' && bg.value) {
    containerStyle = `background-color: ${bg.value};`;
  } else if (bg.type === 'image' && bg.value) {
    const bgSize = bg.imageSize === 'repeat' ? 'auto' : (bg.imageSize || 'cover');
    const bgRepeat = bg.imageSize === 'repeat' ? 'repeat' : 'no-repeat';
    bgLayerHtml = `<div style="position: fixed; top: 0; left: 0; width: 100%; height: 100%; z-index: 0; background-image: url('${bg.value}'); background-size: ${bgSize}; background-position: ${bg.imagePosition || 'center'}; background-repeat: ${bgRepeat}; ${bgFilter}"></div>`;
  } else if (bg.type === 'video' && bg.value) {
    bgLayerHtml = `<video style="position: fixed; top: 0; left: 0; width: 100%; height: 100%; object-fit: cover; z-index: 0; ${bgFilter}" src="${bg.value}" autoplay loop muted playsinline></video>`;
  } else {
    containerStyle = `background-color: ${config.globalStyles.backgroundColor};`;
  }

  // Overlay
  if ((bg.type === 'image' || bg.type === 'video') && bg.overlay && bg.value) {
    const opacity = (bg.overlayOpacity || 50) / 100;
    overlayHtml = `<div style="position: fixed; top: 0; left: 0; width: 100%; height: 100%; z-index: 1; background-color: ${bg.overlayColor || '#000000'}; opacity: ${opacity};"></div>`;
  }

  return `<div class="page${isFirst ? ' active' : ''}" id="page-${page.id}" style="${containerStyle}">
  ${bgLayerHtml}
  ${overlayHtml}
  <div class="page-content">
    ${page.elements.map(el => generateElement(el)).join('\n    ')}
  </div>
</div>`;
}

function generateElement(el: SiteElement): string {
  const styleStr = Object.entries(el.styles).map(([k, v]) => `${camelToKebab(k)}: ${v}`).join('; ');

  switch (el.type) {
    case 'title':
      return `<div class="element"><h1 style="${styleStr}">${escapeHtml(el.content)}</h1></div>`;
    case 'paragraph':
      return `<div class="element"><p style="${styleStr}; white-space: pre-wrap;">${escapeHtml(el.content)}</p></div>`;
    case 'html':
      return `<div class="element" style="${styleStr}">${el.content}</div>`;
    case 'iframe':
      return `<div class="element"><iframe src="${el.content}" style="${styleStr}" title="Embedded content" allowfullscreen></iframe></div>`;
    case 'image':
      return `<div class="element"><img src="${el.content}" alt="Image" style="${styleStr}" loading="lazy" /></div>`;
    case 'video':
      return `<div class="element"><video src="${el.content}" style="${styleStr}" controls></video></div>`;
    case 'button': {
      const btnStyle = Object.entries(el.styles).filter(([k]) => k !== 'textAlign').map(([k, v]) => `${camelToKebab(k)}: ${v}`).join('; ');
      const align = el.styles.textAlign || 'center';
      return `<div class="element" style="text-align: ${align};"><a href="${el.props.link || '#'}" target="${el.props.target || '_self'}" class="btn-link" style="${btnStyle}">${escapeHtml(el.content)}</a></div>`;
    }
    default:
      return '';
  }
}

function camelToKebab(str: string): string {
  return str.replace(/([A-Z])/g, '-$1').toLowerCase();
}

function generateScript(): string {
  return `<script>
function showPage(id) {
  document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('.page-btn').forEach(b => b.classList.remove('active'));
  const page = document.getElementById('page-' + id);
  if (page) page.classList.add('active');
  const btn = document.querySelector('[data-page="' + id + '"]');
  if (btn) btn.classList.add('active');
}
</script>`;
}
