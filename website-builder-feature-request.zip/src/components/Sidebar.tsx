import { useState, useRef } from 'react';
import { useStore } from '../store';
import { ElementType } from '../types';
import { v4 as uuidv4 } from 'uuid';

const elementTypes: { type: ElementType; label: string; icon: string; desc: string }[] = [
  { type: 'title', label: 'Title', icon: '𝐓', desc: 'Heading text' },
  { type: 'paragraph', label: 'Paragraph', icon: '¶', desc: 'Body text' },
  { type: 'html', label: 'HTML Embed', icon: '</>', desc: 'Custom HTML code' },
  { type: 'iframe', label: 'iFrame', icon: '⧉', desc: 'Embed external site' },
  { type: 'image', label: 'Image', icon: '🖼', desc: 'Add image URL' },
  { type: 'video', label: 'Video', icon: '▶', desc: 'Add video' },
  { type: 'button', label: 'Button', icon: '⬜', desc: 'Link button' },
];

export default function Sidebar() {
  const { addElement, config, activePage, addPage, deletePage, renamePage, setActivePage, previewMode, setConfig, setSelectedElementId } = useStore();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [newPageName, setNewPageName] = useState('');
  const [showPages, setShowPages] = useState(false);
  const [editingPageId, setEditingPageId] = useState<string | null>(null);
  const [editPageName, setEditPageName] = useState('');

  if (previewMode) return null;

  return (
    <div className="w-72 bg-gray-900 text-white flex flex-col h-full overflow-y-auto shrink-0">
      {/* Logo */}
      <div className="p-4 border-b border-gray-700">
        <h1 className="text-xl font-bold bg-gradient-to-r from-blue-400 to-purple-500 bg-clip-text text-transparent">
          TaqiSite Builder
        </h1>
        <p className="text-[10px] text-gray-400 mt-1">Created & Owned by Muhammad Taqi</p>
      </div>

      {/* Insert Elements */}
      <div className="p-4 border-b border-gray-700">
        <h2 className="text-sm font-semibold text-gray-300 uppercase tracking-wider mb-3">Insert Elements</h2>
        <div className="grid grid-cols-2 gap-2">
          {elementTypes.map(({ type, label, icon }) => (
            <button
              key={type}
              onClick={() => addElement(type)}
              className="flex flex-col items-center gap-1 p-3 bg-gray-800 hover:bg-gray-700 rounded-lg transition-all hover:scale-105 border border-gray-700 hover:border-blue-500"
            >
              <span className="text-2xl">{icon}</span>
              <span className="text-xs font-medium">{label}</span>
            </button>
          ))}
        </div>

        {/* Upload Image Section */}
        <div className="mt-4">
          <label className="block cursor-pointer">
            <input 
              ref={fileInputRef}
              type="file" 
              accept="image/*"
              className="hidden"
              onChange={(e) => {
                const file = e.target.files?.[0];
                if (file) {
                  const reader = new FileReader();
                  reader.onloadend = () => {
                    const base64 = reader.result as string;
                    // Add image element with base64 data
                    const newElement = {
                      id: uuidv4(),
                      type: 'image' as ElementType,
                      content: base64,
                      styles: { width: '100%', maxHeight: '500px', objectFit: 'cover' as const, borderRadius: '8px' },
                      props: {},
                    };
                    setConfig(prev => ({
                      ...prev,
                      pages: prev.pages.map(p =>
                        p.id === prev.activePageId
                          ? { ...p, elements: [...p.elements, newElement] }
                          : p
                      ),
                    }));
                    setSelectedElementId(newElement.id);
                  };
                  reader.readAsDataURL(file);
                }
                // Reset input
                e.target.value = '';
              }}
            />
            <div className="flex items-center justify-center gap-2 p-3 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-500 hover:to-pink-500 rounded-lg transition-all cursor-pointer border border-purple-500 hover:scale-[1.02]">
              <span className="text-2xl">📁</span>
              <div className="text-left">
                <span className="text-sm font-bold block">Upload Image</span>
                <span className="text-[10px] opacity-80">JPG, PNG, GIF</span>
              </div>
            </div>
          </label>
        </div>
      </div>

      {/* Pages */}
      <div className="p-4 border-b border-gray-700">
        <button
          onClick={() => setShowPages(!showPages)}
          className="flex items-center justify-between w-full text-sm font-semibold text-gray-300 uppercase tracking-wider mb-3"
        >
          <span>Pages ({config.pages.length})</span>
          <span className="text-lg">{showPages ? '▾' : '▸'}</span>
        </button>

        {showPages && (
          <div className="space-y-2">
            {config.pages.map(page => (
              <div
                key={page.id}
                className={`flex items-center gap-2 p-2 rounded-lg cursor-pointer transition-all ${
                  page.id === activePage.id
                    ? 'bg-blue-600 text-white'
                    : 'bg-gray-800 hover:bg-gray-700 text-gray-300'
                }`}
              >
                {editingPageId === page.id ? (
                  <input
                    className="flex-1 bg-gray-900 text-white text-sm px-2 py-1 rounded border border-gray-600"
                    value={editPageName}
                    onChange={e => setEditPageName(e.target.value)}
                    onBlur={() => {
                      renamePage(page.id, editPageName);
                      setEditingPageId(null);
                    }}
                    onKeyDown={e => {
                      if (e.key === 'Enter') {
                        renamePage(page.id, editPageName);
                        setEditingPageId(null);
                      }
                    }}
                    autoFocus
                  />
                ) : (
                  <>
                    <span
                      className="flex-1 text-sm truncate"
                      onClick={() => setActivePage(page.id)}
                    >
                      {page.name}
                    </span>
                    <button
                      onClick={() => {
                        setEditingPageId(page.id);
                        setEditPageName(page.name);
                      }}
                      className="text-xs opacity-60 hover:opacity-100"
                      title="Rename"
                    >
                      ✏️
                    </button>
                    {config.pages.length > 1 && (
                      <button
                        onClick={() => deletePage(page.id)}
                        className="text-xs opacity-60 hover:opacity-100"
                        title="Delete"
                      >
                        🗑️
                      </button>
                    )}
                  </>
                )}
              </div>
            ))}

            <div className="flex gap-2 mt-3">
              <input
                className="flex-1 bg-gray-800 text-white text-sm px-3 py-2 rounded-lg border border-gray-600 placeholder-gray-500"
                placeholder="Page name..."
                value={newPageName}
                onChange={e => setNewPageName(e.target.value)}
                onKeyDown={e => {
                  if (e.key === 'Enter' && newPageName.trim()) {
                    addPage(newPageName.trim());
                    setNewPageName('');
                  }
                }}
              />
              <button
                onClick={() => {
                  if (newPageName.trim()) {
                    addPage(newPageName.trim());
                    setNewPageName('');
                  }
                }}
                className="px-3 py-2 bg-green-600 hover:bg-green-500 rounded-lg text-sm font-medium transition-all"
              >
                + Add
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Credits */}
      <div className="mt-auto p-4 border-t border-gray-700">
        <div className="text-center">
          <p className="text-[10px] text-gray-500">Created & Owned by</p>
          <p className="text-sm font-bold text-blue-400">Muhammad Taqi</p>
        </div>
      </div>
    </div>
  );
}
