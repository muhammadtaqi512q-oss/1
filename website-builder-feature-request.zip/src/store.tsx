import React, { createContext, useContext, useState, useCallback } from 'react';
import { v4 as uuidv4 } from 'uuid';
import { SiteConfig, SitePage, SiteElement, ElementType, PageBackground } from './types';

const getDefaultBackground = (): PageBackground => ({
  type: 'none',
  value: '',
  imageSize: 'cover',
  imagePosition: 'center',
  overlay: false,
  overlayColor: '#000000',
  overlayOpacity: 50,
  brightness: 100,
  blur: 0,
});

const defaultPage: SitePage = {
  id: uuidv4(),
  name: 'Home',
  elements: [],
  background: getDefaultBackground(),
};

const defaultConfig: SiteConfig = {
  title: 'My Website',
  pages: [defaultPage],
  activePageId: defaultPage.id,
  globalStyles: {
    fontFamily: 'Inter, sans-serif',
    primaryColor: '#4285f4',
    backgroundColor: '#ffffff',
  },
};

interface StoreContextType {
  config: SiteConfig;
  setConfig: React.Dispatch<React.SetStateAction<SiteConfig>>;
  activePage: SitePage;
  selectedElementId: string | null;
  setSelectedElementId: (id: string | null) => void;
  addElement: (type: ElementType) => void;
  updateElement: (id: string, updates: Partial<SiteElement>) => void;
  deleteElement: (id: string) => void;
  moveElement: (id: string, direction: 'up' | 'down') => void;
  duplicateElement: (id: string) => void;
  addPage: (name: string) => void;
  deletePage: (id: string) => void;
  renamePage: (id: string, name: string) => void;
  setActivePage: (id: string) => void;
  setPageBackground: (pageId: string, bg: PageBackground) => void;
  updateGlobalStyles: (styles: Partial<SiteConfig['globalStyles']>) => void;
  previewMode: boolean;
  setPreviewMode: (v: boolean) => void;
}

const StoreContext = createContext<StoreContextType | null>(null);

export function StoreProvider({ children }: { children: React.ReactNode }) {
  const [config, setConfig] = useState<SiteConfig>(defaultConfig);
  const [selectedElementId, setSelectedElementId] = useState<string | null>(null);
  const [previewMode, setPreviewMode] = useState(false);

  const activePage = config.pages.find(p => p.id === config.activePageId) || config.pages[0];

  const addElement = useCallback((type: ElementType) => {
    const newElement: SiteElement = {
      id: uuidv4(),
      type,
      content: getDefaultContent(type),
      styles: getDefaultStyles(type),
      props: getDefaultProps(type),
    };
    setConfig(prev => ({
      ...prev,
      pages: prev.pages.map(p =>
        p.id === prev.activePageId
          ? { ...p, elements: [...p.elements, newElement] }
          : p
      ),
    }));
    setSelectedElementId(newElement.id);
  }, []);

  const updateElement = useCallback((id: string, updates: Partial<SiteElement>) => {
    setConfig(prev => ({
      ...prev,
      pages: prev.pages.map(p =>
        p.id === prev.activePageId
          ? {
              ...p,
              elements: p.elements.map(el =>
                el.id === id ? { ...el, ...updates } : el
              ),
            }
          : p
      ),
    }));
  }, []);

  const deleteElement = useCallback((id: string) => {
    setConfig(prev => ({
      ...prev,
      pages: prev.pages.map(p =>
        p.id === prev.activePageId
          ? { ...p, elements: p.elements.filter(el => el.id !== id) }
          : p
      ),
    }));
    setSelectedElementId(null);
  }, []);

  const moveElement = useCallback((id: string, direction: 'up' | 'down') => {
    setConfig(prev => ({
      ...prev,
      pages: prev.pages.map(p => {
        if (p.id !== prev.activePageId) return p;
        const idx = p.elements.findIndex(el => el.id === id);
        if (idx === -1) return p;
        const newIdx = direction === 'up' ? idx - 1 : idx + 1;
        if (newIdx < 0 || newIdx >= p.elements.length) return p;
        const newElements = [...p.elements];
        [newElements[idx], newElements[newIdx]] = [newElements[newIdx], newElements[idx]];
        return { ...p, elements: newElements };
      }),
    }));
  }, []);

  const duplicateElement = useCallback((id: string) => {
    setConfig(prev => ({
      ...prev,
      pages: prev.pages.map(p => {
        if (p.id !== prev.activePageId) return p;
        const el = p.elements.find(e => e.id === id);
        if (!el) return p;
        const newEl = { ...el, id: uuidv4(), styles: { ...el.styles }, props: { ...el.props } };
        const idx = p.elements.findIndex(e => e.id === id);
        const newElements = [...p.elements];
        newElements.splice(idx + 1, 0, newEl);
        return { ...p, elements: newElements };
      }),
    }));
  }, []);

  const addPage = useCallback((name: string) => {
    const newPage: SitePage = {
      id: uuidv4(),
      name: name || 'New Page',
      elements: [],
      background: getDefaultBackground(),
    };
    setConfig(prev => ({
      ...prev,
      pages: [...prev.pages, newPage],
      activePageId: newPage.id,
    }));
  }, []);

  const deletePage = useCallback((id: string) => {
    setConfig(prev => {
      if (prev.pages.length <= 1) return prev;
      const newPages = prev.pages.filter(p => p.id !== id);
      return {
        ...prev,
        pages: newPages,
        activePageId: prev.activePageId === id ? newPages[0].id : prev.activePageId,
      };
    });
  }, []);

  const renamePage = useCallback((id: string, name: string) => {
    setConfig(prev => ({
      ...prev,
      pages: prev.pages.map(p => (p.id === id ? { ...p, name } : p)),
    }));
  }, []);

  const setActivePage = useCallback((id: string) => {
    setConfig(prev => ({ ...prev, activePageId: id }));
    setSelectedElementId(null);
  }, []);

  const setPageBackground = useCallback((pageId: string, bg: PageBackground) => {
    setConfig(prev => ({
      ...prev,
      pages: prev.pages.map(p => (p.id === pageId ? { ...p, background: bg } : p)),
    }));
  }, []);

  const updateGlobalStyles = useCallback((styles: Partial<SiteConfig['globalStyles']>) => {
    setConfig(prev => ({
      ...prev,
      globalStyles: { ...prev.globalStyles, ...styles },
    }));
  }, []);

  return (
    <StoreContext.Provider
      value={{
        config,
        setConfig,
        activePage,
        selectedElementId,
        setSelectedElementId,
        addElement,
        updateElement,
        deleteElement,
        moveElement,
        duplicateElement,
        addPage,
        deletePage,
        renamePage,
        setActivePage,
        setPageBackground,
        updateGlobalStyles,
        previewMode,
        setPreviewMode,
      }}
    >
      {children}
    </StoreContext.Provider>
  );
}

export function useStore() {
  const ctx = useContext(StoreContext);
  if (!ctx) throw new Error('useStore must be used within StoreProvider');
  return ctx;
}

function getDefaultContent(type: ElementType): string {
  switch (type) {
    case 'title': return 'Your Title Here';
    case 'paragraph': return 'Enter your text here. Click to edit this paragraph.';
    case 'html': return '<div style="padding:20px;background:#f0f0f0;border-radius:8px;"><h3>Custom HTML</h3><p>Edit this HTML code</p></div>';
    case 'iframe': return 'https://www.wikipedia.org';
    case 'image': return 'https://images.unsplash.com/photo-1506744038136-46273834b3fb?w=800';
    case 'video': return 'https://www.w3schools.com/html/mov_bbb.mp4';
    case 'button': return 'Click Me';
    default: return '';
  }
}

function getDefaultStyles(type: ElementType): Record<string, string> {
  switch (type) {
    case 'title': return { fontSize: '36px', fontWeight: '700', color: '#1a1a1a', textAlign: 'center', padding: '16px' };
    case 'paragraph': return { fontSize: '16px', color: '#444444', textAlign: 'left', padding: '12px', lineHeight: '1.6' };
    case 'html': return { padding: '12px' };
    case 'iframe': return { width: '100%', height: '400px', border: 'none', borderRadius: '8px' };
    case 'image': return { width: '100%', maxHeight: '500px', objectFit: 'cover', borderRadius: '8px' };
    case 'video': return { width: '100%', maxHeight: '500px', borderRadius: '8px' };
    case 'button': return { backgroundColor: '#4285f4', color: '#ffffff', padding: '12px 32px', fontSize: '16px', fontWeight: '600', borderRadius: '8px', border: 'none', cursor: 'pointer', textAlign: 'center' };
    default: return {};
  }
}

function getDefaultProps(type: ElementType): Record<string, string> {
  switch (type) {
    case 'button': return { link: '#', target: '_self' };
    case 'iframe': return { allowFullscreen: 'true' };
    default: return {};
  }
}
