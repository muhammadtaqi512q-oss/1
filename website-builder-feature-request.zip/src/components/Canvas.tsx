import { useStore } from '../store';
import { SiteElement } from '../types';

export default function Canvas() {
  const { activePage, selectedElementId, setSelectedElementId, previewMode, config } = useStore();

  const bg = activePage.background;
  const bgStyle: React.CSSProperties = {};
  
  if (bg.type === 'color') {
    bgStyle.backgroundColor = bg.value;
  } else if (bg.type === 'image' && bg.value) {
    bgStyle.backgroundImage = `url(${bg.value})`;
    bgStyle.backgroundSize = bg.imageSize === 'repeat' ? 'auto' : (bg.imageSize || 'cover');
    bgStyle.backgroundPosition = bg.imagePosition || 'center';
    bgStyle.backgroundRepeat = bg.imageSize === 'repeat' ? 'repeat' : 'no-repeat';
    bgStyle.backgroundAttachment = 'fixed';
  }

  // Filter for image/video backgrounds
  const bgFilter = (bg.type === 'image' || bg.type === 'video') && bg.value
    ? `brightness(${bg.brightness || 100}%) blur(${bg.blur || 0}px)`
    : undefined;

  return (
    <div
      className="flex-1 overflow-y-auto bg-gray-200"
      onClick={() => setSelectedElementId(null)}
    >
      <div className="max-w-[900px] mx-auto my-8 min-h-[calc(100vh-100px)] relative shadow-2xl rounded-lg overflow-hidden"
        style={{
          fontFamily: config.globalStyles.fontFamily,
          backgroundColor: bg.type === 'none' ? config.globalStyles.backgroundColor : undefined,
        }}
      >
        {/* Image Background Layer */}
        {bg.type === 'image' && bg.value && (
          <div
            className="absolute inset-0 z-0"
            style={{
              backgroundImage: `url(${bg.value})`,
              backgroundSize: bg.imageSize === 'repeat' ? 'auto' : (bg.imageSize || 'cover'),
              backgroundPosition: bg.imagePosition || 'center',
              backgroundRepeat: bg.imageSize === 'repeat' ? 'repeat' : 'no-repeat',
              filter: bgFilter,
            }}
          />
        )}

        {/* Video Background */}
        {bg.type === 'video' && bg.value && (
          <video
            key={bg.value}
            className="absolute inset-0 w-full h-full object-cover z-0"
            src={bg.value}
            autoPlay
            loop
            muted
            playsInline
            style={{
              filter: bgFilter,
            }}
          />
        )}

        {/* Color Overlay */}
        {(bg.type === 'image' || bg.type === 'video') && bg.overlay && bg.value && (
          <div
            className="absolute inset-0 z-[1]"
            style={{
              backgroundColor: bg.overlayColor || '#000000',
              opacity: (bg.overlayOpacity || 50) / 100,
            }}
          />
        )}

        {/* Color Background */}
        {bg.type === 'color' && (
          <div
            className="absolute inset-0 z-0"
            style={{ backgroundColor: bg.value }}
          />
        )}

        {/* Content overlay */}
        <div className="relative z-10 min-h-[calc(100vh-100px)]">
          {/* Page Navigation Bar */}
          {!previewMode && (
            <div className="bg-white/90 backdrop-blur-sm border-b border-gray-200 px-4 py-2 flex items-center gap-2 text-sm">
              <span className="text-gray-400 text-xs font-medium">Page:</span>
              <span className="font-semibold text-gray-700">{activePage.name}</span>
              <span className="ml-auto text-gray-400 text-xs">{activePage.elements.length} elements</span>
            </div>
          )}

          {/* Elements */}
          <div className="p-6 space-y-4">
            {activePage.elements.length === 0 && !previewMode && (
              <div className="flex flex-col items-center justify-center py-32 text-gray-400">
                <p className="text-6xl mb-4">🎨</p>
                <p className="text-lg font-medium">Start building your page</p>
                <p className="text-sm mt-1">Add elements from the left sidebar</p>
              </div>
            )}

            {activePage.elements.map(element => (
              <ElementRenderer
                key={element.id}
                element={element}
                isSelected={element.id === selectedElementId}
                onSelect={() => setSelectedElementId(element.id)}
                previewMode={previewMode}
              />
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

function ElementRenderer({
  element, isSelected, onSelect, previewMode
}: {
  element: SiteElement;
  isSelected: boolean;
  onSelect: () => void;
  previewMode: boolean;
}) {
  const handleClick = (e: React.MouseEvent) => {
    if (previewMode) return;
    e.stopPropagation();
    onSelect();
  };

  const wrapperClass = previewMode
    ? ''
    : `cursor-pointer transition-all duration-150 rounded-lg ${
        isSelected
          ? 'ring-2 ring-blue-500 ring-offset-2 bg-blue-50/30'
          : 'hover:ring-2 hover:ring-blue-300 hover:ring-offset-1'
      }`;

  return (
    <div className={wrapperClass} onClick={handleClick}>
      {renderElement(element, previewMode)}
    </div>
  );
}

function renderElement(el: SiteElement, previewMode: boolean) {
  const style: React.CSSProperties = { ...el.styles } as any;

  switch (el.type) {
    case 'title':
      return <h1 style={style}>{el.content}</h1>;

    case 'paragraph':
      return <p style={style} className="whitespace-pre-wrap">{el.content}</p>;

    case 'html':
      return (
        <div style={style} dangerouslySetInnerHTML={{ __html: el.content }} />
      );

    case 'iframe':
      return (
        <iframe
          src={el.content}
          style={style}
          title="Embedded content"
          allowFullScreen
          sandbox="allow-scripts allow-same-origin allow-popups"
        />
      );

    case 'image':
      return (
        <img
          src={el.content}
          alt="Site image"
          style={style}
          className="block mx-auto"
          loading="lazy"
        />
      );

    case 'video':
      return (
        <video
          src={el.content}
          style={style}
          controls
          className="block mx-auto"
        />
      );

    case 'button':
      if (previewMode) {
        return (
          <div style={{ textAlign: style.textAlign || 'center' }}>
            <a
              href={el.props.link || '#'}
              target={el.props.target || '_self'}
              rel="noopener noreferrer"
              style={{ ...style, display: 'inline-block', textDecoration: 'none' }}
            >
              {el.content}
            </a>
          </div>
        );
      }
      return (
        <div style={{ textAlign: style.textAlign || 'center' }}>
          <span style={{ ...style, display: 'inline-block' }}>{el.content}</span>
        </div>
      );

    default:
      return <div>Unknown element type</div>;
  }
}
