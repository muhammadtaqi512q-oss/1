import { StoreProvider } from './store';
import Sidebar from './components/Sidebar';
import Canvas from './components/Canvas';
import PropertiesPanel from './components/PropertiesPanel';
import Toolbar from './components/Toolbar';

export default function App() {
  return (
    <StoreProvider>
      <div className="h-screen w-screen flex flex-col overflow-hidden bg-gray-100">
        <Toolbar />
        <div className="flex flex-1 overflow-hidden">
          <SidebarWrapper />
          <Canvas />
          <PropertiesPanelWrapper />
        </div>
      </div>
    </StoreProvider>
  );
}

function SidebarWrapper() {
  return <Sidebar />;
}

function PropertiesPanelWrapper() {
  return <PropertiesPanel />;
}
