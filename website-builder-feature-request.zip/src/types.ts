export type ElementType = 'title' | 'paragraph' | 'html' | 'iframe' | 'image' | 'video' | 'button';

export interface SiteElement {
  id: string;
  type: ElementType;
  content: string;
  styles: Record<string, string>;
  props: Record<string, string>;
}

export interface PageBackground {
  type: 'none' | 'color' | 'image' | 'video';
  value: string;
  imageSize: 'cover' | 'contain' | 'auto' | 'repeat';
  imagePosition: string;
  overlay: boolean;
  overlayColor: string;
  overlayOpacity: number;
  brightness: number;
  blur: number;
}

export interface SitePage {
  id: string;
  name: string;
  elements: SiteElement[];
  background: PageBackground;
}

export interface SiteConfig {
  title: string;
  pages: SitePage[];
  activePageId: string;
  globalStyles: {
    fontFamily: string;
    primaryColor: string;
    backgroundColor: string;
  };
}
