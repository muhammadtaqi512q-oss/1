import { useState } from 'react';
import { useStore } from '../store';
import { PageBackground } from '../types';

const VIDEO_BACKGROUNDS = [
  'https://assets.mixkit.co/videos/preview/mixkit-clouds-and-blue-sky-2408-large.mp4',
  'https://assets.mixkit.co/videos/preview/mixkit-going-down-a-curved-road-through-a-mountain-range-41576-large.mp4',
  'https://assets.mixkit.co/videos/preview/mixkit-top-aerial-shot-of-seashore-702-large.mp4',
  'https://assets.mixkit.co/videos/preview/mixkit-stars-in-space-1610-large.mp4',
  'https://assets.mixkit.co/videos/preview/mixkit-forest-stream-in-the-sunlight-529-large.mp4',
  'https://assets.mixkit.co/videos/preview/mixkit-abstract-technology-lines-background-44487-large.mp4',
  'https://assets.mixkit.co/videos/preview/mixkit-night-sky-with-stars-at-a-calm-lake-21862-large.mp4',
  'https://assets.mixkit.co/videos/preview/mixkit-waterfall-in-forest-2213-large.mp4',
  'https://assets.mixkit.co/videos/preview/mixkit-sunset-over-the-sea-4783-large.mp4',
  'https://assets.mixkit.co/videos/preview/mixkit-aerial-view-of-city-traffic-at-night-11-large.mp4',
  'https://assets.mixkit.co/videos/preview/mixkit-rain-falling-on-the-water-of-a-lake-seen-up-18312-large.mp4',
  'https://assets.mixkit.co/videos/preview/mixkit-spinning-around-the-earth-29351-large.mp4',
  'https://assets.mixkit.co/videos/preview/mixkit-white-sand-beach-and-turquoise-water-1564-large.mp4',
  'https://assets.mixkit.co/videos/preview/mixkit-fire-in-nature-close-up-1712-large.mp4',
  'https://assets.mixkit.co/videos/preview/mixkit-snow-covered-mountain-3318-large.mp4',
  'https://assets.mixkit.co/videos/preview/mixkit-red-and-orange-ink-abstract-52130-large.mp4',
  'https://assets.mixkit.co/videos/preview/mixkit-abstract-lights-in-a-dark-background-44809-large.mp4',
  'https://assets.mixkit.co/videos/preview/mixkit-highway-in-the-middle-of-a-mountain-702-large.mp4',
  'https://assets.mixkit.co/videos/preview/mixkit-waves-in-the-water-1164-large.mp4',
  'https://assets.mixkit.co/videos/preview/mixkit-blue-and-purple-futuristic-globe-29742-large.mp4',
];

const VIDEO_LABELS = [
  'Clouds & Blue Sky', 'Mountain Road', 'Seashore Aerial', 'Stars in Space', 'Forest Stream',
  'Tech Lines', 'Night Sky Lake', 'Waterfall Forest', 'Sunset Sea', 'City Night Traffic',
  'Rain on Lake', 'Spinning Earth', 'Sandy Beach', 'Fire Close-up', 'Snow Mountain',
  'Red Ink Abstract', 'Dark Lights', 'Mountain Highway', 'Water Waves', 'Futuristic Globe',
];

const IMAGE_BACKGROUNDS = [
  'https://images.unsplash.com/photo-1506744038136-46273834b3fb?w=1920',
  'https://images.unsplash.com/photo-1477346611705-65d1883cee1e?w=1920',
  'https://images.unsplash.com/photo-1470071459604-3b5ec3a7fe05?w=1920',
  'https://images.unsplash.com/photo-1441974231531-c6227db76b6e?w=1920',
  'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=1920',
  'https://images.unsplash.com/photo-1519681393784-d120267933ba?w=1920',
  'https://images.unsplash.com/photo-1465146344425-f00d5f5c8f07?w=1920',
  'https://images.unsplash.com/photo-1501785888041-af3ef285b470?w=1920',
  'https://images.unsplash.com/photo-1472214103451-9374bd1c798e?w=1920',
  'https://images.unsplash.com/photo-1500534314263-0869cef1ddd6?w=1920',
  'https://images.unsplash.com/photo-1468276311594-df7cb65d8df6?w=1920',
  'https://images.unsplash.com/photo-1504198453319-5ce911bafcde?w=1920',
  'https://images.unsplash.com/photo-1490730141103-6cac27aaab94?w=1920',
  'https://images.unsplash.com/photo-1418065460487-3e41a6c84dc5?w=1920',
  'https://images.unsplash.com/photo-1433086966358-54859d0ed716?w=1920',
  'https://images.unsplash.com/photo-1469474968028-56623f02e42e?w=1920',
  'https://images.unsplash.com/photo-1447752875215-b2761acb3c5d?w=1920',
  'https://images.unsplash.com/photo-1414609245224-afa02bfb3fda?w=1920',
  'https://images.unsplash.com/photo-1431440869543-efaf3388c585?w=1920',
  'https://images.unsplash.com/photo-1500829243541-74b677fecc30?w=1920',
];

const IMAGE_LABELS = [
  'Mountain Lake', 'Mountain Fog', 'Green Valley', 'Forest Path', 'Tropical Beach',
  'Starry Mountain', 'Orange Flowers', 'Scenic Overlook', 'Green Fields', 'Desert Sunset',
  'Night Ocean', 'Sky Colors', 'Sunrise Silhouette', 'Misty Forest', 'Waterfall Bridge',
  'Valley View', 'Forest Trail', 'Calm Lake', 'Rocky Coast', 'Golden Prairie',
];

export default function PropertiesPanel() {
  const {
    activePage, selectedElementId, updateElement, deleteElement,
    moveElement, duplicateElement, setPageBackground, previewMode, config, updateGlobalStyles
  } = useStore();
  const [bgTab, setBgTab] = useState<'element' | 'page' | 'style'>('element');

  if (previewMode) return null;

  const selectedElement = activePage.elements.find(el => el.id === selectedElementId);

  return (
    <div className="w-80 bg-gray-50 border-l border-gray-200 flex flex-col h-full overflow-y-auto shrink-0">
      {/* Tabs */}
      <div className="flex border-b border-gray-200">
        <button
          onClick={() => setBgTab('element')}
          className={`flex-1 py-3 text-sm font-medium transition-all ${bgTab === 'element' ? 'text-blue-600 border-b-2 border-blue-600 bg-white' : 'text-gray-500 hover:text-gray-700'}`}
        >
          Element
        </button>
        <button
          onClick={() => setBgTab('page')}
          className={`flex-1 py-3 text-sm font-medium transition-all ${bgTab === 'page' ? 'text-blue-600 border-b-2 border-blue-600 bg-white' : 'text-gray-500 hover:text-gray-700'}`}
        >
          Background
        </button>
        <button
          onClick={() => setBgTab('style')}
          className={`flex-1 py-3 text-sm font-medium transition-all ${bgTab === 'style' ? 'text-blue-600 border-b-2 border-blue-600 bg-white' : 'text-gray-500 hover:text-gray-700'}`}
        >
          Style
        </button>
      </div>

      <div className="p-4 flex-1">
        {bgTab === 'element' && selectedElement && (
          <ElementEditor
            element={selectedElement}
            onUpdate={(updates) => updateElement(selectedElement.id, updates)}
            onDelete={() => deleteElement(selectedElement.id)}
            onMove={(dir) => moveElement(selectedElement.id, dir)}
            onDuplicate={() => duplicateElement(selectedElement.id)}
          />
        )}

        {bgTab === 'element' && !selectedElement && (
          <div className="text-center text-gray-400 mt-12">
            <p className="text-4xl mb-3">👆</p>
            <p className="text-sm">Select an element to edit its properties</p>
          </div>
        )}

        {bgTab === 'page' && (
          <BackgroundEditor
            background={activePage.background}
            onChange={(bg) => setPageBackground(activePage.id, bg)}
          />
        )}

        {bgTab === 'style' && (
          <StyleEditor
            globalStyles={config.globalStyles}
            onChange={updateGlobalStyles}
          />
        )}
      </div>
    </div>
  );
}

function ElementEditor({
  element, onUpdate, onDelete, onMove, onDuplicate
}: {
  element: any;
  onUpdate: (u: any) => void;
  onDelete: () => void;
  onMove: (dir: 'up' | 'down') => void;
  onDuplicate: () => void;
}) {
  return (
    <div className="space-y-4">
      {/* Actions */}
      <div className="flex gap-2">
        <button onClick={() => onMove('up')} className="flex-1 py-2 bg-gray-200 hover:bg-gray-300 rounded text-sm">⬆ Up</button>
        <button onClick={() => onMove('down')} className="flex-1 py-2 bg-gray-200 hover:bg-gray-300 rounded text-sm">⬇ Down</button>
        <button onClick={onDuplicate} className="flex-1 py-2 bg-blue-100 hover:bg-blue-200 text-blue-700 rounded text-sm">📋 Copy</button>
        <button onClick={onDelete} className="flex-1 py-2 bg-red-100 hover:bg-red-200 text-red-700 rounded text-sm">🗑️</button>
      </div>

      <div className="bg-blue-50 px-3 py-2 rounded-lg">
        <span className="text-xs font-semibold text-blue-600 uppercase">{element.type}</span>
      </div>

      {/* Content */}
      <div>
        <label className="block text-xs font-semibold text-gray-600 mb-1">
          {element.type === 'iframe' ? 'URL' : element.type === 'image' ? 'Image URL' : element.type === 'video' ? 'Video URL' : 'Content'}
        </label>
        {element.type === 'html' || element.type === 'paragraph' ? (
          <textarea
            className="w-full bg-white border border-gray-300 rounded-lg p-2 text-sm font-mono resize-y min-h-[100px]"
            value={element.content}
            onChange={e => onUpdate({ content: e.target.value })}
            rows={6}
          />
        ) : (
          <input
            className="w-full bg-white border border-gray-300 rounded-lg p-2 text-sm"
            value={element.content}
            onChange={e => onUpdate({ content: e.target.value })}
          />
        )}
      </div>

      {/* Button props */}
      {element.type === 'button' && (
        <>
          <div>
            <label className="block text-xs font-semibold text-gray-600 mb-1">Link URL</label>
            <input
              className="w-full bg-white border border-gray-300 rounded-lg p-2 text-sm"
              value={element.props.link || ''}
              onChange={e => onUpdate({ props: { ...element.props, link: e.target.value } })}
              placeholder="https://..."
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-gray-600 mb-1">Open In</label>
            <select
              className="w-full bg-white border border-gray-300 rounded-lg p-2 text-sm"
              value={element.props.target || '_self'}
              onChange={e => onUpdate({ props: { ...element.props, target: e.target.value } })}
            >
              <option value="_self">Same Tab</option>
              <option value="_blank">New Tab</option>
            </select>
          </div>
        </>
      )}

      {/* Style Properties */}
      <div className="border-t border-gray-200 pt-4">
        <h3 className="text-xs font-semibold text-gray-600 uppercase mb-3">Styling</h3>
        <div className="space-y-3">
          {element.styles.fontSize !== undefined && (
            <StyleField label="Font Size" value={element.styles.fontSize} onChange={v => onUpdate({ styles: { ...element.styles, fontSize: v } })} />
          )}
          {element.styles.fontWeight !== undefined && (
            <StyleField label="Font Weight" value={element.styles.fontWeight} onChange={v => onUpdate({ styles: { ...element.styles, fontWeight: v } })} />
          )}
          {element.styles.color !== undefined && (
            <ColorField label="Text Color" value={element.styles.color} onChange={v => onUpdate({ styles: { ...element.styles, color: v } })} />
          )}
          {element.styles.backgroundColor !== undefined && (
            <ColorField label="Background" value={element.styles.backgroundColor} onChange={v => onUpdate({ styles: { ...element.styles, backgroundColor: v } })} />
          )}
          {element.styles.textAlign !== undefined && (
            <div>
              <label className="block text-xs font-semibold text-gray-600 mb-1">Text Align</label>
              <div className="flex gap-1">
                {['left', 'center', 'right', 'justify'].map(a => (
                  <button
                    key={a}
                    onClick={() => onUpdate({ styles: { ...element.styles, textAlign: a } })}
                    className={`flex-1 py-1.5 rounded text-xs font-medium ${element.styles.textAlign === a ? 'bg-blue-600 text-white' : 'bg-gray-200 text-gray-600 hover:bg-gray-300'}`}
                  >
                    {a.charAt(0).toUpperCase() + a.slice(1)}
                  </button>
                ))}
              </div>
            </div>
          )}
          {element.styles.padding !== undefined && (
            <StyleField label="Padding" value={element.styles.padding} onChange={v => onUpdate({ styles: { ...element.styles, padding: v } })} />
          )}
          {element.styles.borderRadius !== undefined && (
            <StyleField label="Border Radius" value={element.styles.borderRadius} onChange={v => onUpdate({ styles: { ...element.styles, borderRadius: v } })} />
          )}
          {element.styles.width !== undefined && (
            <StyleField label="Width" value={element.styles.width} onChange={v => onUpdate({ styles: { ...element.styles, width: v } })} />
          )}
          {(element.styles.height !== undefined || element.styles.maxHeight !== undefined) && (
            <StyleField label="Height" value={element.styles.height || element.styles.maxHeight || ''} onChange={v => {
              if (element.styles.height !== undefined) onUpdate({ styles: { ...element.styles, height: v } });
              else onUpdate({ styles: { ...element.styles, maxHeight: v } });
            }} />
          )}
        </div>
      </div>
    </div>
  );
}

function StyleField({ label, value, onChange }: { label: string; value: string; onChange: (v: string) => void }) {
  return (
    <div>
      <label className="block text-xs font-semibold text-gray-600 mb-1">{label}</label>
      <input className="w-full bg-white border border-gray-300 rounded-lg p-2 text-sm" value={value} onChange={e => onChange(e.target.value)} />
    </div>
  );
}

function ColorField({ label, value, onChange }: { label: string; value: string; onChange: (v: string) => void }) {
  return (
    <div>
      <label className="block text-xs font-semibold text-gray-600 mb-1">{label}</label>
      <div className="flex gap-2">
        <input type="color" className="w-10 h-10 rounded border border-gray-300 cursor-pointer" value={value} onChange={e => onChange(e.target.value)} />
        <input className="flex-1 bg-white border border-gray-300 rounded-lg p-2 text-sm" value={value} onChange={e => onChange(e.target.value)} />
      </div>
    </div>
  );
}

function BackgroundEditor({ background, onChange }: { background: PageBackground; onChange: (bg: PageBackground) => void }) {
  const [customUrl, setCustomUrl] = useState('');

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const base64 = reader.result as string;
        onChange({ ...background, type: 'image', value: base64 });
      };
      reader.readAsDataURL(file);
    }
  };

  const updateBgSettings = (updates: Partial<PageBackground>) => {
    onChange({ ...background, ...updates });
  };

  const defaultBgSettings: Partial<PageBackground> = {
    imageSize: background.imageSize || 'cover',
    imagePosition: background.imagePosition || 'center',
    overlay: background.overlay || false,
    overlayColor: background.overlayColor || '#000000',
    overlayOpacity: background.overlayOpacity ?? 50,
    brightness: background.brightness ?? 100,
    blur: background.blur ?? 0,
  };

  return (
    <div className="space-y-4">
      <h3 className="text-sm font-semibold text-gray-700">Page Background</h3>

      {/* Type selector */}
      <div className="flex gap-1">
        {(['none', 'color', 'image', 'video'] as const).map(t => (
          <button
            key={t}
            onClick={() => onChange({ 
              ...background, 
              type: t, 
              value: t === 'color' ? '#ffffff' : (t === background.type ? background.value : ''),
              ...defaultBgSettings
            })}
            className={`flex-1 py-2 rounded text-xs font-medium capitalize ${background.type === t ? 'bg-blue-600 text-white' : 'bg-gray-200 text-gray-600 hover:bg-gray-300'}`}
          >
            {t}
          </button>
        ))}
      </div>

      {background.type === 'color' && (
        <ColorField label="Background Color" value={background.value || '#ffffff'} onChange={v => updateBgSettings({ value: v })} />
      )}

      {background.type === 'image' && (
        <div className="space-y-3">
          {/* Upload Image */}
          <div>
            <label className="block text-xs font-semibold text-gray-600 mb-2">📁 Upload Your Image</label>
            <label className="flex items-center justify-center w-full h-24 border-2 border-dashed border-blue-400 rounded-lg bg-blue-50 hover:bg-blue-100 cursor-pointer transition-colors">
              <input 
                type="file" 
                accept="image/*" 
                onChange={handleImageUpload}
                className="hidden"
              />
              <div className="text-center">
                <span className="text-3xl">📷</span>
                <p className="text-xs text-blue-600 font-medium mt-1">Click to upload image</p>
                <p className="text-[10px] text-gray-500">JPG, PNG, GIF supported</p>
              </div>
            </label>
          </div>

          {/* Current background preview */}
          {background.value && (
            <div className="relative">
              <label className="block text-xs font-semibold text-gray-600 mb-1">Current Background</label>
              <div className="relative h-32 rounded-lg overflow-hidden border border-gray-300">
                <img 
                  src={background.value.startsWith('data:') ? background.value : background.value + '&w=400'} 
                  alt="Current background" 
                  className="w-full h-full object-cover"
                  style={{
                    filter: `brightness(${background.brightness || 100}%) blur(${background.blur || 0}px)`
                  }}
                />
                {background.overlay && (
                  <div 
                    className="absolute inset-0" 
                    style={{ 
                      backgroundColor: background.overlayColor || '#000000',
                      opacity: (background.overlayOpacity || 50) / 100
                    }}
                  />
                )}
                <button
                  onClick={() => updateBgSettings({ value: '' })}
                  className="absolute top-2 right-2 bg-red-500 text-white p-1 rounded-full hover:bg-red-600 text-xs"
                >
                  ✕
                </button>
              </div>
            </div>
          )}

          {/* Image Settings */}
          <div className="bg-gray-100 p-3 rounded-lg space-y-3">
            <h4 className="text-xs font-semibold text-gray-700 uppercase">Image Settings</h4>
            
            <div>
              <label className="block text-xs font-semibold text-gray-600 mb-1">Size</label>
              <select
                className="w-full bg-white border border-gray-300 rounded-lg p-2 text-sm"
                value={background.imageSize || 'cover'}
                onChange={e => updateBgSettings({ imageSize: e.target.value as any })}
              >
                <option value="cover">Cover (Fill)</option>
                <option value="contain">Contain (Fit)</option>
                <option value="auto">Original Size</option>
                <option value="repeat">Repeat/Tile</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-gray-600 mb-1">Position</label>
              <select
                className="w-full bg-white border border-gray-300 rounded-lg p-2 text-sm"
                value={background.imagePosition || 'center'}
                onChange={e => updateBgSettings({ imagePosition: e.target.value })}
              >
                <option value="center">Center</option>
                <option value="top">Top</option>
                <option value="bottom">Bottom</option>
                <option value="left">Left</option>
                <option value="right">Right</option>
                <option value="top left">Top Left</option>
                <option value="top right">Top Right</option>
                <option value="bottom left">Bottom Left</option>
                <option value="bottom right">Bottom Right</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-gray-600 mb-1">
                Brightness: {background.brightness || 100}%
              </label>
              <input
                type="range"
                min="20"
                max="150"
                value={background.brightness || 100}
                onChange={e => updateBgSettings({ brightness: parseInt(e.target.value) })}
                className="w-full"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-gray-600 mb-1">
                Blur: {background.blur || 0}px
              </label>
              <input
                type="range"
                min="0"
                max="20"
                value={background.blur || 0}
                onChange={e => updateBgSettings({ blur: parseInt(e.target.value) })}
                className="w-full"
              />
            </div>

            {/* Overlay */}
            <div className="border-t border-gray-300 pt-3">
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={background.overlay || false}
                  onChange={e => updateBgSettings({ overlay: e.target.checked })}
                  className="w-4 h-4 rounded"
                />
                <span className="text-xs font-semibold text-gray-600">Add Color Overlay</span>
              </label>
              
              {background.overlay && (
                <div className="mt-2 space-y-2">
                  <div className="flex gap-2 items-center">
                    <input 
                      type="color" 
                      value={background.overlayColor || '#000000'}
                      onChange={e => updateBgSettings({ overlayColor: e.target.value })}
                      className="w-8 h-8 rounded cursor-pointer"
                    />
                    <span className="text-xs text-gray-600">Overlay Color</span>
                  </div>
                  <div>
                    <label className="block text-xs text-gray-600 mb-1">
                      Opacity: {background.overlayOpacity || 50}%
                    </label>
                    <input
                      type="range"
                      min="0"
                      max="100"
                      value={background.overlayOpacity || 50}
                      onChange={e => updateBgSettings({ overlayOpacity: parseInt(e.target.value) })}
                      className="w-full"
                    />
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Custom URL */}
          <div>
            <label className="block text-xs font-semibold text-gray-600 mb-1">Or Enter Image URL</label>
            <div className="flex gap-2">
              <input
                className="flex-1 bg-white border border-gray-300 rounded-lg p-2 text-sm"
                value={customUrl}
                onChange={e => setCustomUrl(e.target.value)}
                placeholder="https://..."
              />
              <button
                onClick={() => { if (customUrl) updateBgSettings({ value: customUrl }); setCustomUrl(''); }}
                className="px-3 py-2 bg-blue-600 text-white rounded-lg text-sm hover:bg-blue-500"
              >
                Set
              </button>
            </div>
          </div>
          
          <h4 className="text-xs font-semibold text-gray-500 uppercase pt-2">Choose from Gallery (20 Images)</h4>
          <div className="grid grid-cols-2 gap-2 max-h-[300px] overflow-y-auto">
            {IMAGE_BACKGROUNDS.map((url, i) => (
              <button
                key={i}
                onClick={() => updateBgSettings({ value: url })}
                className={`relative h-20 rounded-lg overflow-hidden border-2 transition-all ${background.value === url ? 'border-blue-500 ring-2 ring-blue-300' : 'border-gray-200 hover:border-gray-400'}`}
              >
                <img src={url + '&q=30&w=200'} alt={IMAGE_LABELS[i]} className="w-full h-full object-cover" />
                <div className="absolute inset-0 bg-black/30 flex items-end p-1">
                  <span className="text-[9px] text-white font-medium">{IMAGE_LABELS[i]}</span>
                </div>
              </button>
            ))}
          </div>
        </div>
      )}

      {background.type === 'video' && (
        <div className="space-y-3">
          {/* Video Settings */}
          {background.value && (
            <div className="bg-gray-100 p-3 rounded-lg space-y-3">
              <h4 className="text-xs font-semibold text-gray-700 uppercase">Video Settings</h4>
              
              <div>
                <label className="block text-xs font-semibold text-gray-600 mb-1">
                  Brightness: {background.brightness || 100}%
                </label>
                <input
                  type="range"
                  min="20"
                  max="150"
                  value={background.brightness || 100}
                  onChange={e => updateBgSettings({ brightness: parseInt(e.target.value) })}
                  className="w-full"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-600 mb-1">
                  Blur: {background.blur || 0}px
                </label>
                <input
                  type="range"
                  min="0"
                  max="20"
                  value={background.blur || 0}
                  onChange={e => updateBgSettings({ blur: parseInt(e.target.value) })}
                  className="w-full"
                />
              </div>

              {/* Overlay */}
              <div className="border-t border-gray-300 pt-3">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={background.overlay || false}
                    onChange={e => updateBgSettings({ overlay: e.target.checked })}
                    className="w-4 h-4 rounded"
                  />
                  <span className="text-xs font-semibold text-gray-600">Add Color Overlay</span>
                </label>
                
                {background.overlay && (
                  <div className="mt-2 space-y-2">
                    <div className="flex gap-2 items-center">
                      <input 
                        type="color" 
                        value={background.overlayColor || '#000000'}
                        onChange={e => updateBgSettings({ overlayColor: e.target.value })}
                        className="w-8 h-8 rounded cursor-pointer"
                      />
                      <span className="text-xs text-gray-600">Overlay Color</span>
                    </div>
                    <div>
                      <label className="block text-xs text-gray-600 mb-1">
                        Opacity: {background.overlayOpacity || 50}%
                      </label>
                      <input
                        type="range"
                        min="0"
                        max="100"
                        value={background.overlayOpacity || 50}
                        onChange={e => updateBgSettings({ overlayOpacity: parseInt(e.target.value) })}
                        className="w-full"
                      />
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}

          <div>
            <label className="block text-xs font-semibold text-gray-600 mb-1">Custom Video URL</label>
            <div className="flex gap-2">
              <input
                className="flex-1 bg-white border border-gray-300 rounded-lg p-2 text-sm"
                value={customUrl}
                onChange={e => setCustomUrl(e.target.value)}
                placeholder="https://..."
              />
              <button
                onClick={() => { if (customUrl) updateBgSettings({ value: customUrl }); setCustomUrl(''); }}
                className="px-3 py-2 bg-blue-600 text-white rounded-lg text-sm hover:bg-blue-500"
              >
                Set
              </button>
            </div>
          </div>
          <h4 className="text-xs font-semibold text-gray-500 uppercase">Choose Background (20 Videos)</h4>
          <div className="space-y-2 max-h-[300px] overflow-y-auto">
            {VIDEO_BACKGROUNDS.map((url, i) => (
              <button
                key={i}
                onClick={() => updateBgSettings({ value: url })}
                className={`w-full text-left p-2 rounded-lg border-2 transition-all text-sm ${background.value === url ? 'border-blue-500 bg-blue-50 text-blue-700' : 'border-gray-200 bg-white hover:border-gray-400'}`}
              >
                ▶ {VIDEO_LABELS[i]}
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

function StyleEditor({ globalStyles, onChange }: { globalStyles: any; onChange: (s: any) => void }) {
  return (
    <div className="space-y-4">
      <h3 className="text-sm font-semibold text-gray-700">Global Styles</h3>
      <div>
        <label className="block text-xs font-semibold text-gray-600 mb-1">Font Family</label>
        <select
          className="w-full bg-white border border-gray-300 rounded-lg p-2 text-sm"
          value={globalStyles.fontFamily}
          onChange={e => onChange({ fontFamily: e.target.value })}
        >
          <option value="Inter, sans-serif">Inter</option>
          <option value="Georgia, serif">Georgia (Serif)</option>
          <option value="'Courier New', monospace">Courier New (Mono)</option>
          <option value="Arial, sans-serif">Arial</option>
          <option value="'Times New Roman', serif">Times New Roman</option>
          <option value="Verdana, sans-serif">Verdana</option>
          <option value="'Trebuchet MS', sans-serif">Trebuchet MS</option>
        </select>
      </div>
      <ColorField label="Primary Color" value={globalStyles.primaryColor} onChange={v => onChange({ primaryColor: v })} />
      <ColorField label="Page Background Color" value={globalStyles.backgroundColor} onChange={v => onChange({ backgroundColor: v })} />
    </div>
  );
}
