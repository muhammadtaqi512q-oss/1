import { useStore } from '../store';
import { generateHTML } from '../utils/exportHtml';

export default function Toolbar() {
  const { config, previewMode, setPreviewMode, activePage, setActivePage } = useStore();

  const handleExport = () => {
    const html = generateHTML(config);
    const blob = new Blob([html], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'index.html';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="h-14 bg-white border-b border-gray-200 flex items-center px-4 gap-3 shrink-0 shadow-sm z-50">
      {/* Site Title */}
      <div className="flex items-center gap-2">
        <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center">
          <span className="text-white font-bold text-sm">T</span>
        </div>
        <div>
          <h1 className="text-sm font-bold text-gray-800 leading-tight">{config.title}</h1>
          <p className="text-[9px] text-gray-400">by Muhammad Taqi</p>
        </div>
      </div>

      {/* Page Tabs */}
      <div className="flex-1 flex items-center gap-1 ml-6 overflow-x-auto">
        {config.pages.map(page => (
          <button
            key={page.id}
            onClick={() => setActivePage(page.id)}
            className={`px-4 py-1.5 rounded-full text-sm font-medium transition-all whitespace-nowrap ${
              page.id === activePage.id
                ? 'bg-blue-600 text-white shadow-md'
                : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
            }`}
          >
            {page.name}
          </button>
        ))}
      </div>

      {/* Actions */}
      <div className="flex items-center gap-2">
        <button
          onClick={() => setPreviewMode(!previewMode)}
          className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${
            previewMode
              ? 'bg-green-600 text-white hover:bg-green-700'
              : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
          }`}
        >
          {previewMode ? '✏️ Edit' : '👁️ Preview'}
        </button>

        <button
          onClick={handleExport}
          className="px-4 py-2 bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-lg text-sm font-medium hover:from-blue-700 hover:to-purple-700 transition-all shadow-md"
        >
          ⬇️ Download HTML
        </button>
      </div>
    </div>
  );
}
